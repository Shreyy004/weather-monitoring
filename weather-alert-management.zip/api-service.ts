// API service for interacting with the Flask backend

// Base URL for the API
const API_BASE_URL = "http://localhost:5001"

// Interface for weather data
export interface WeatherData {
  temperature: number
  humidity: number
  pressure: number
  wind_speed: number
  cloudiness: number
  precipitation: number
}

// Interface for alert configuration
export interface AlertConfig {
  parameter: keyof WeatherData
  threshold: number
  condition: "above" | "below"
  location: string
  email: string
}

// Get current weather for a location by coordinates
export async function getWeatherByCoordinates(lat: number, lon: number): Promise<WeatherData> {
  try {
    const response = await fetch(`${API_BASE_URL}/weather?lat=${lat}&lon=${lon}`)
    if (!response.ok) {
      throw new Error("Failed to fetch weather data")
    }
    return await response.json()
  } catch (error) {
    console.error("Error fetching weather data:", error)
    throw error
  }
}

// Get coordinates for a city name
export async function getCoordinatesForCity(city: string): Promise<{ lat: number; lon: number }> {
  try {
    // This would typically call the backend's geocoding endpoint
    // For now, we'll simulate it with a mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        // Mock coordinates for demonstration
        const coordinates = {
          lat: 28.6139 + (Math.random() - 0.5) * 2,
          lon: 77.209 + (Math.random() - 0.5) * 2,
        }
        resolve(coordinates)
      }, 500)
    })
  } catch (error) {
    console.error("Error getting coordinates:", error)
    throw error
  }
}

// Check if an alert condition is met
export function checkAlertCondition(
  weatherData: WeatherData,
  parameter: keyof WeatherData,
  threshold: number,
  condition: "above" | "below",
): boolean {
  const value = weatherData[parameter]
  return condition === "above" ? value > threshold : value < threshold
}

// Send email notification
export async function sendEmailNotification(email: string, subject: string, message: string): Promise<boolean> {
  try {
    // This would typically call your email sending service
    // For now, we'll simulate it with a mock implementation
    return new Promise((resolve) => {
      setTimeout(() => {
        console.log(`Email sent to ${email}: ${subject} - ${message}`)
        resolve(true)
      }, 1000)
    })
  } catch (error) {
    console.error("Error sending email:", error)
    return false
  }
}

// Schedule regular weather updates
export function scheduleWeatherUpdates(
  frequency: number, // in hours
  email: string,
  location: string,
): { cancel: () => void } {
  const intervalId = setInterval(
    async () => {
      try {
        // Get coordinates for the location
        const { lat, lon } = await getCoordinatesForCity(location)

        // Get current weather
        const weatherData = await getWeatherByCoordinates(lat, lon)

        // Send email with weather update
        await sendEmailNotification(
          email,
          `Weather Update for ${location}`,
          `Current weather in ${location}: Temperature: ${weatherData.temperature}°C, Humidity: ${weatherData.humidity}%, Wind: ${weatherData.wind_speed} km/h`,
        )
      } catch (error) {
        console.error("Error in scheduled weather update:", error)
      }
    },
    frequency * 60 * 60 * 1000,
  ) // Convert hours to milliseconds

  // Return a function to cancel the interval
  return {
    cancel: () => clearInterval(intervalId),
  }
}

// Get weather radar data
export async function getWeatherRadar(location: string): Promise<string> {
  try {
    // This would typically call the backend's radar endpoint
    // For now, we'll return a placeholder URL
    return `https://radar.weather.gov/?location=${encodeURIComponent(location)}`
  } catch (error) {
    console.error("Error getting weather radar:", error)
    throw error
  }
}

