"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/hooks/use-toast"
import { scheduleWeatherUpdates } from "./api-service"

interface SchedulerState {
  enabled: boolean
  frequency: "6" | "8" | "12"
  email: string
  location: string
  activeSchedule: { cancel: () => void } | null
}

export default function EmailScheduler() {
  const [state, setState] = useState<SchedulerState>({
    enabled: false,
    frequency: "12",
    email: "",
    location: "",
    activeSchedule: null,
  })

  // Load saved settings from localStorage on component mount
  useEffect(() => {
    const savedSettings = localStorage.getItem("emailSchedulerSettings")
    if (savedSettings) {
      const parsed = JSON.parse(savedSettings)
      setState((prev) => ({
        ...prev,
        enabled: parsed.enabled,
        frequency: parsed.frequency,
        email: parsed.email,
        location: parsed.location,
      }))

      // If it was enabled, restart the schedule
      if (parsed.enabled) {
        startSchedule(parsed.frequency, parsed.email, parsed.location)
      }
    }

    // Cleanup on unmount
    return () => {
      if (state.activeSchedule) {
        state.activeSchedule.cancel()
      }
    }
  }, [])

  // Save settings to localStorage when they change
  useEffect(() => {
    localStorage.setItem(
      "emailSchedulerSettings",
      JSON.stringify({
        enabled: state.enabled,
        frequency: state.frequency,
        email: state.email,
        location: state.location,
      }),
    )
  }, [state.enabled, state.frequency, state.email, state.location])

  // Handle toggle of enabled state
  const handleToggleEnabled = (enabled: boolean) => {
    if (enabled) {
      if (!state.email || !state.location) {
        toast({
          title: "Missing information",
          description: "Please provide both email and location",
          variant: "destructive",
        })
        return
      }

      startSchedule(state.frequency, state.email, state.location)
    } else {
      if (state.activeSchedule) {
        state.activeSchedule.cancel()
      }
    }

    setState((prev) => ({ ...prev, enabled }))
  }

  // Start the schedule
  const startSchedule = (frequency: string, email: string, location: string) => {
    // Cancel any existing schedule
    if (state.activeSchedule) {
      state.activeSchedule.cancel()
    }

    // Start a new schedule
    const activeSchedule = scheduleWeatherUpdates(Number.parseInt(frequency), email, location)

    setState((prev) => ({ ...prev, activeSchedule }))

    toast({
      title: "Schedule activated",
      description: `You'll receive weather updates every ${frequency} hours`,
    })
  }

  // Save settings
  const handleSaveSettings = () => {
    if (!state.email || !state.location) {
      toast({
        title: "Missing information",
        description: "Please provide both email and location",
        variant: "destructive",
      })
      return
    }

    if (state.enabled) {
      startSchedule(state.frequency, state.email, state.location)
    }

    toast({
      title: "Settings saved",
      description: state.enabled
        ? `You'll receive weather updates every ${state.frequency} hours`
        : "Regular weather updates are disabled",
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Email Notification Schedule</CardTitle>
        <CardDescription>Receive regular weather updates via email</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center space-x-2">
          <Switch id="schedule-enabled" checked={state.enabled} onCheckedChange={handleToggleEnabled} />
          <Label htmlFor="schedule-enabled">Enable scheduled weather updates</Label>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={state.email}
              onChange={(e) => setState((prev) => ({ ...prev, email: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              placeholder="City name"
              value={state.location}
              onChange={(e) => setState((prev) => ({ ...prev, location: e.target.value }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="frequency">Update Frequency</Label>
            <Select
              value={state.frequency}
              onValueChange={(value: "6" | "8" | "12") => setState((prev) => ({ ...prev, frequency: value }))}
            >
              <SelectTrigger id="frequency">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6">Every 6 hours</SelectItem>
                <SelectItem value="8">Every 8 hours</SelectItem>
                <SelectItem value="12">Every 12 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSaveSettings}>Save Settings</Button>
      </CardFooter>
    </Card>
  )
}

