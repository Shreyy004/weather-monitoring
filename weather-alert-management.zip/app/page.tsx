"use client"

import AlertDashboard from "../alert-dashboard"

export default function SyntheticV0PageForDeployment() {
  return <AlertDashboard />
}