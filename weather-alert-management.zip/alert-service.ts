import {
  getWeatherByCoordinates,
  getCoordinatesForCity,
  checkAlertCondition,
  sendEmailNotification,
  type WeatherData,
} from "./api-service"

// Interface for an alert
export interface Alert {
  id: string
  parameter: keyof WeatherData
  threshold: number
  condition: "above" | "below"
  enabled: boolean
  location?: string
  email?: string
  lastTriggered?: Date
}

// Class to manage weather alerts
export class AlertService {
  private alerts: Alert[] = []
  private checkInterval: number = 30 * 60 * 1000 // 30 minutes in milliseconds
  private intervalId: NodeJS.Timeout | null = null
  private location = ""
  private email = ""

  constructor() {
    // Load saved alerts from localStorage
    this.loadAlerts()
  }

  // Set user location and email
  public setUserInfo(location: string, email: string): void {
    this.location = location
    this.email = email
    this.saveUserInfo()
  }

  // Add a new alert
  public addAlert(alert: Omit<Alert, "id">): string {
    const id = Math.random().toString(36).substring(2, 9)
    const newAlert: Alert = { ...alert, id }
    this.alerts.push(newAlert)
    this.saveAlerts()
    return id
  }

  // Remove an alert
  public removeAlert(id: string): void {
    this.alerts = this.alerts.filter((alert) => alert.id !== id)
    this.saveAlerts()
  }

  // Update an alert
  public updateAlert(id: string, updates: Partial<Alert>): void {
    this.alerts = this.alerts.map((alert) => (alert.id === id ? { ...alert, ...updates } : alert))
    this.saveAlerts()
  }

  // Get all alerts
  public getAlerts(): Alert[] {
    return [...this.alerts]
  }

  // Start monitoring alerts
  public startMonitoring(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId)
    }

    this.intervalId = setInterval(() => {
      this.checkAlerts()
    }, this.checkInterval)

    // Also check immediately
    this.checkAlerts()
  }

  // Stop monitoring alerts
  public stopMonitoring(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId)
      this.intervalId = null
    }
  }

  // Check all enabled alerts
  private async checkAlerts(): Promise<void> {
    if (!this.location || !this.email) {
      console.warn("Location or email not set, cannot check alerts")
      return
    }

    try {
      // Get coordinates for the location
      const { lat, lon } = await getCoordinatesForCity(this.location)

      // Get current weather
      const weatherData = await getWeatherByCoordinates(lat, lon)

      // Check each enabled alert
      for (const alert of this.alerts) {
        if (!alert.enabled) continue

        const isTriggered = checkAlertCondition(weatherData, alert.parameter, alert.threshold, alert.condition)

        if (isTriggered) {
          // Check if this alert was recently triggered (within the last hour)
          const now = new Date()
          const lastTriggered = alert.lastTriggered ? new Date(alert.lastTriggered) : null
          const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000)

          if (!lastTriggered || lastTriggered < oneHourAgo) {
            // Send notification
            await this.sendAlertNotification(alert, weatherData)

            // Update last triggered time
            this.updateAlert(alert.id, { lastTriggered: now })
          }
        }
      }
    } catch (error) {
      console.error("Error checking alerts:", error)
    }
  }

  // Send notification for triggered alert
  private async sendAlertNotification(alert: Alert, weatherData: WeatherData): Promise<void> {
    const parameterName = alert.parameter.charAt(0).toUpperCase() + alert.parameter.slice(1)
    const value = weatherData[alert.parameter]
    const condition = alert.condition === "above" ? "exceeded" : "dropped below"

    const subject = `Weather Alert: ${parameterName} ${condition} threshold`
    const message = `
      Weather Alert for ${this.location}:
      
      The ${parameterName.toLowerCase()} has ${condition} your set threshold of ${alert.threshold}.
      Current value: ${value}
      
      Current weather conditions:
      Temperature: ${weatherData.temperature}°C
      Humidity: ${weatherData.humidity}%
      Wind Speed: ${weatherData.wind_speed} km/h
      Precipitation: ${weatherData.precipitation} mm
    `

    await sendEmailNotification(this.email, subject, message)
  }

  // Save alerts to localStorage
  private saveAlerts(): void {
    localStorage.setItem("weatherAlerts", JSON.stringify(this.alerts))
  }

  // Load alerts from localStorage
  private loadAlerts(): void {
    const savedAlerts = localStorage.getItem("weatherAlerts")
    if (savedAlerts) {
      this.alerts = JSON.parse(savedAlerts)
    }

    const userInfo = localStorage.getItem("userInfo")
    if (userInfo) {
      const { location, email } = JSON.parse(userInfo)
      this.location = location
      this.email = email
    }
  }

  // Save user info to localStorage
  private saveUserInfo(): void {
    localStorage.setItem(
      "userInfo",
      JSON.stringify({
        location: this.location,
        email: this.email,
      }),
    )
  }
}

// Create and export a singleton instance
export const alertService = new AlertService()

