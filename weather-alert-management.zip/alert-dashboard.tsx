"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertTriangle, Clock, MapPin } from "lucide-react"
import AlertManagement from "./alert-management"
import EmailScheduler from "./email-scheduler"
import WeatherRadar from "./weather-radar"

export default function AlertDashboard() {
  const [activeTab, setActiveTab] = useState("alerts")

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <h1 className="text-3xl font-bold mb-6">Weather Alert Dashboard</h1>

      <Tabs defaultValue="alerts" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="alerts">
            <AlertTriangle className="mr-2 h-4 w-4" />
            Alert Thresholds
          </TabsTrigger>
          <TabsTrigger value="schedule">
            <Clock className="mr-2 h-4 w-4" />
            Email Schedule
          </TabsTrigger>
          <TabsTrigger value="radar">
            <MapPin className="mr-2 h-4 w-4" />
            Weather Radar
          </TabsTrigger>
        </TabsList>

        <TabsContent value="alerts">
          <AlertManagement />
        </TabsContent>

        <TabsContent value="schedule">
          <EmailScheduler />
        </TabsContent>

        <TabsContent value="radar">
          <WeatherRadar />
        </TabsContent>
      </Tabs>
    </div>
  )
}

