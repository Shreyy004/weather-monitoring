"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { getWeatherRadar } from "./api-service"
import { toast } from "@/hooks/use-toast"

export default function WeatherRadar() {
  const [location, setLocation] = useState("")
  const [radarUrl, setRadarUrl] = useState("")
  const [loading, setLoading] = useState(false)

  // Load saved location from localStorage on component mount
  useEffect(() => {
    const savedLocation = localStorage.getItem("radarLocation")
    if (savedLocation) {
      setLocation(savedLocation)
      fetchRadar(savedLocation)
    }
  }, [])

  // Fetch radar data for the location
  const fetchRadar = async (loc: string) => {
    if (!loc) return

    setLoading(true)
    try {
      const url = await getWeatherRadar(loc)
      setRadarUrl(url)
      localStorage.setItem("radarLocation", loc)
    } catch (error) {
      console.error("Error fetching radar:", error)
      toast({
        title: "Error",
        description: "Failed to fetch weather radar data",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    fetchRadar(location)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Weather Radar</CardTitle>
        <CardDescription>View real-time weather radar for your location</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="radar-location">Location</Label>
            <div className="flex space-x-2">
              <Input
                id="radar-location"
                placeholder="Enter city name"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
              <Button type="submit" disabled={loading || !location}>
                {loading ? "Loading..." : "View Radar"}
              </Button>
            </div>
          </div>
        </form>

        {radarUrl && (
          <div className="mt-4">
            <h3 className="text-lg font-medium mb-2">Weather Radar for {location}</h3>
            <div className="aspect-video w-full bg-muted rounded-md overflow-hidden">
              <iframe
                src={radarUrl}
                className="w-full h-full border-0"
                title={`Weather radar for ${location}`}
                allowFullScreen
              />
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Radar data updates every 10 minutes. Last updated: {new Date().toLocaleTimeString()}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

