"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Bell, Clock, AlertTriangle, Trash2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface Alert {
  id: string
  parameter: string
  threshold: number
  condition: "above" | "below"
  enabled: boolean
}

interface TimePreference {
  frequency: "6" | "8" | "12" | "none"
  enabled: boolean
  email: string
}

export default function AlertManagement() {
  // State for alert thresholds
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [newAlert, setNewAlert] = useState<Omit<Alert, "id">>({
    parameter: "temperature",
    threshold: 30,
    condition: "above",
    enabled: true,
  })

  // State for time preferences
  const [timePreference, setTimePreference] = useState<TimePreference>({
    frequency: "12",
    enabled: false,
    email: "",
  })

  // State for radar settings
  const [radarEnabled, setRadarEnabled] = useState(false)
  const [radarLocation, setRadarLocation] = useState("")

  // Load saved settings from localStorage on component mount
  useEffect(() => {
    const savedAlerts = localStorage.getItem("weatherAlerts")
    const savedTimePreference = localStorage.getItem("timePreference")
    const savedRadarSettings = localStorage.getItem("radarSettings")

    if (savedAlerts) setAlerts(JSON.parse(savedAlerts))
    if (savedTimePreference) setTimePreference(JSON.parse(savedTimePreference))
    if (savedRadarSettings) {
      const radar = JSON.parse(savedRadarSettings)
      setRadarEnabled(radar.enabled)
      setRadarLocation(radar.location)
    }
  }, [])

  // Save settings to localStorage when they change
  useEffect(() => {
    localStorage.setItem("weatherAlerts", JSON.stringify(alerts))
  }, [alerts])

  useEffect(() => {
    localStorage.setItem("timePreference", JSON.stringify(timePreference))
  }, [timePreference])

  useEffect(() => {
    localStorage.setItem(
      "radarSettings",
      JSON.stringify({
        enabled: radarEnabled,
        location: radarLocation,
      }),
    )
  }, [radarEnabled, radarLocation])

  // Add a new alert
  const handleAddAlert = () => {
    const newId = Math.random().toString(36).substring(2, 9)
    setAlerts([...alerts, { ...newAlert, id: newId }])
    toast({
      title: "Alert created",
      description: `You'll be notified when ${newAlert.parameter} goes ${newAlert.condition} ${newAlert.threshold}`,
    })
  }

  // Remove an alert
  const handleRemoveAlert = (id: string) => {
    setAlerts(alerts.filter((alert) => alert.id !== id))
    toast({
      title: "Alert removed",
      description: "The alert has been removed from your notifications",
    })
  }

  // Toggle alert enabled state
  const handleToggleAlert = (id: string) => {
    setAlerts(alerts.map((alert) => (alert.id === id ? { ...alert, enabled: !alert.enabled } : alert)))
  }

  // Save time preference
  const handleSaveTimePreference = () => {
    toast({
      title: "Time preference saved",
      description: timePreference.enabled
        ? `You'll receive weather updates every ${timePreference.frequency} hours`
        : "Regular weather updates are disabled",
    })
  }

  // Save radar settings
  const handleSaveRadarSettings = () => {
    toast({
      title: "Radar settings saved",
      description: radarEnabled ? `Weather radar is enabled for ${radarLocation}` : "Weather radar is disabled",
    })
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <h1 className="text-3xl font-bold mb-6">Weather Alert Management</h1>

      <Tabs defaultValue="thresholds">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="thresholds">
            <AlertTriangle className="mr-2 h-4 w-4" />
            Alert Thresholds
          </TabsTrigger>
          <TabsTrigger value="schedule">
            <Clock className="mr-2 h-4 w-4" />
            Time Preferences
          </TabsTrigger>
          <TabsTrigger value="radar">
            <Bell className="mr-2 h-4 w-4" />
            Weather Radar
          </TabsTrigger>
        </TabsList>

        {/* Alert Thresholds Tab */}
        <TabsContent value="thresholds">
          <Card>
            <CardHeader>
              <CardTitle>Set Weather Alert Thresholds</CardTitle>
              <CardDescription>Get notified when weather parameters cross your specified thresholds</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="parameter">Weather Parameter</Label>
                  <Select
                    value={newAlert.parameter}
                    onValueChange={(value) => setNewAlert({ ...newAlert, parameter: value })}
                  >
                    <SelectTrigger id="parameter">
                      <SelectValue placeholder="Select parameter" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="temperature">Temperature (°C)</SelectItem>
                      <SelectItem value="humidity">Humidity (%)</SelectItem>
                      <SelectItem value="precipitation">Precipitation (mm)</SelectItem>
                      <SelectItem value="wind_speed">Wind Speed (km/h)</SelectItem>
                      <SelectItem value="pressure">Pressure (hPa)</SelectItem>
                      <SelectItem value="cloudiness">Cloudiness (%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="condition">Condition</Label>
                  <Select
                    value={newAlert.condition}
                    onValueChange={(value: "above" | "below") => setNewAlert({ ...newAlert, condition: value })}
                  >
                    <SelectTrigger id="condition">
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="above">Above</SelectItem>
                      <SelectItem value="below">Below</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="threshold">Threshold Value</Label>
                  <Input
                    id="threshold"
                    type="number"
                    value={newAlert.threshold}
                    onChange={(e) => setNewAlert({ ...newAlert, threshold: Number.parseFloat(e.target.value) })}
                  />
                </div>

                <div className="flex items-end">
                  <Button onClick={handleAddAlert} className="w-full">
                    Add Alert
                  </Button>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-medium mb-2">Your Alerts</h3>
                {alerts.length === 0 ? (
                  <p className="text-muted-foreground">No alerts set. Add your first alert above.</p>
                ) : (
                  <div className="space-y-2">
                    {alerts.map((alert) => (
                      <div key={alert.id} className="flex items-center justify-between p-3 border rounded-md">
                        <div className="flex items-center space-x-2">
                          <Switch checked={alert.enabled} onCheckedChange={() => handleToggleAlert(alert.id)} />
                          <span className={alert.enabled ? "" : "text-muted-foreground"}>
                            {alert.parameter.charAt(0).toUpperCase() + alert.parameter.slice(1)} {alert.condition}{" "}
                            {alert.threshold}
                          </span>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => handleRemoveAlert(alert.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Time Preferences Tab */}
        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Set Time Preferences</CardTitle>
              <CardDescription>Choose how often you want to receive weather updates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center space-x-2">
                <Switch
                  id="time-enabled"
                  checked={timePreference.enabled}
                  onCheckedChange={(checked) => setTimePreference({ ...timePreference, enabled: checked })}
                />
                <Label htmlFor="time-enabled">Enable regular weather updates</Label>
              </div>

              {timePreference.enabled && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="frequency">Update Frequency</Label>
                    <Select
                      value={timePreference.frequency}
                      onValueChange={(value: "6" | "8" | "12") =>
                        setTimePreference({ ...timePreference, frequency: value })
                      }
                      disabled={!timePreference.enabled}
                    >
                      <SelectTrigger id="frequency">
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="6">Every 6 hours</SelectItem>
                        <SelectItem value="8">Every 8 hours</SelectItem>
                        <SelectItem value="12">Every 12 hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={timePreference.email}
                      onChange={(e) => setTimePreference({ ...timePreference, email: e.target.value })}
                      disabled={!timePreference.enabled}
                    />
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveTimePreference}>Save Preferences</Button>
            </CardFooter>
          </Card>
        </TabsContent>

        {/* Weather Radar Tab */}
        <TabsContent value="radar">
          <Card>
            <CardHeader>
              <CardTitle>Weather Radar Settings</CardTitle>
              <CardDescription>Configure weather radar notifications for your location</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center space-x-2">
                <Switch id="radar-enabled" checked={radarEnabled} onCheckedChange={setRadarEnabled} />
                <Label htmlFor="radar-enabled">Enable weather radar alerts</Label>
              </div>

              {radarEnabled && (
                <div className="space-y-2">
                  <Label htmlFor="location">Your Location</Label>
                  <Input
                    id="location"
                    placeholder="City name"
                    value={radarLocation}
                    onChange={(e) => setRadarLocation(e.target.value)}
                    disabled={!radarEnabled}
                  />
                  <p className="text-sm text-muted-foreground mt-1">
                    We'll send you radar updates for severe weather in this location
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveRadarSettings}>Save Radar Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

