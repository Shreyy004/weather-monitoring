import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { db } from './firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import Autosuggest from 'react-autosuggest';
import './home.css';
import WeatherGraph from './WeatherGraph';
import Weatherapp from './Weatherapp';
import Ranking from './Ranking';
import Ifr from './Ifr'; // Import the Ifr component
import Home from './Home';
// Import required components from recharts
import {
    ResponsiveContainer,
    LineChart,
    Line,
    CartesianGrid,
    XAxis,
    YAxis,
    Tooltip,
    Legend
} from 'recharts';
import WeatherDashboard from './WeatherDashboard';

function Home1() {
    const navigate = useNavigate();
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [userEmail, setUserEmail] = useState("");
    const [preferredLocation, setPreferredLocation] = useState("");
    const [locationInput, setLocationInput] = useState("");
    const [locations, setLocations] = useState(["New York", "Los Angeles", "Chicago", "Houston", "Phoenix"]);
    const [isEditing, setIsEditing] = useState(false);
    const [aqiData, setAqiData] = useState("");
    const [weatherData, setWeatherData] = useState([]);
    const [predictionData, setPredictionData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [activeComponent, setActiveComponent] = useState('default');
    const [selectedParams, setSelectedParams] = useState(["temp"]); // Default to temperature
    const [unit, setUnit] = useState("C"); // Default to Celsius

    useEffect(() => {
        const email = localStorage.getItem("userEmail");
        if (email) {
            setUserEmail(email);
            fetchPreferredLocation(email);
        }
    }, []);

    useEffect(() => {
        if (preferredLocation) {
            fetchAqiAndWeatherData(preferredLocation);
        }
    }, [preferredLocation]);

    const fetchPreferredLocation = async (email) => {
        const docRef = doc(db, "users", email);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
            setPreferredLocation(docSnap.data().location);
        }
    };

    const handleCheckboxChange = (param) => {
        setSelectedParams((prev) =>
            prev.includes(param) ? prev.filter(p => p !== param) : [...prev, param]
        );
    };

    const fetchAqiAndWeatherData = async (location) => {
        setLoading(true);
        try {
            const aqiResponse = await fetch('http://127.0.0.1:5000/fetch-aqi', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ query: location })
            });
            const aqiResult = await aqiResponse.json();
            setAqiData(aqiResult.html || "");

            const weatherResponse = await fetch('http://127.0.0.1:5000/fetch-weather', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ query: location })
            });
            const weatherResult = await weatherResponse.json();
            setWeatherData(convertTemperature(weatherResult || [], unit));

            const predictionResponse = await fetch('http://127.0.0.1:5000/predict-weather', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ city: location })
            });
            const predictionResult = await predictionResponse.json();

            if (predictionResult && predictionResult.predictions) {
                setPredictionData(convertTemperature(predictionResult.predictions, unit));
                console.log("Weather Prediction Data:", predictionResult);
            } else {
                console.error("Invalid prediction data format:", predictionResult);
                setPredictionData([]);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            setLoading(false);
        }
    };

    const convertTemperature = (data, unit) => {
        return data.map(item => {
            const convertedItem = { ...item };
            if (unit === "F") {
                if (convertedItem.temp) convertedItem.temp = (convertedItem.temp * 9/5) + 32;
                if (convertedItem.templow) convertedItem.templow = (convertedItem.templow * 9/5) + 32;
            } else {
                if (convertedItem.temp) convertedItem.temp = (convertedItem.temp - 32) * 5/9;
                if (convertedItem.templow) convertedItem.templow = (convertedItem.templow - 32) * 5/9;
            }
            return convertedItem;
        });
    };

    const toggleUnit = () => {
        const newUnit = unit === "C" ? "F" : "C";
        setUnit(newUnit);
        setWeatherData(convertTemperature(weatherData, newUnit));
        setPredictionData(convertTemperature(predictionData, newUnit));
    };

    const handleLocationSubmit = async (e) => {
        e.preventDefault();
        if (userEmail) {
            await setDoc(doc(db, "users", userEmail), {
                location: locationInput
            });
            setPreferredLocation(locationInput);
            setLocationInput("");
            setIsEditing(false);
        }
    };

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const handleLogout = () => {
        localStorage.removeItem("userEmail");
        navigate("/"); // Redirect to login page
    };

    return (
        <div className="container">
            <header className="header2">
                <div className="logo">
                    <i className="fas fa-utensils"></i> Logo
                </div>
                <nav className="navbar">
                    <a href="#">Home</a>
                    <a href="#footer">About</a>
                    <a href="#footer">Services</a>
                    <a href="#footer">Contact</a>
                </nav>
                <div className="user-info">
                    {isEditing ? (
                        <form onSubmit={handleLocationSubmit} style={{ display: 'inline' }}>
                            <div className="user-info1">
                                <label>
                                    Preferred Location:
                                    <Autosuggest
                                        suggestions={[]}
                                        onSuggestionsFetchRequested={() => { }}
                                        onSuggestionsClearRequested={() => { }}
                                        getSuggestionValue={(suggestion) => suggestion}
                                        renderSuggestion={(suggestion) => <div>{suggestion}</div>}
                                        inputProps={{
                                            placeholder: 'Select a location',
                                            value: locationInput,
                                            onChange: (e, { newValue }) => setLocationInput(newValue)
                                        }}
                                    />
                                </label>
                            </div>
                            <button type="submit">Save</button>
                        </form>
                    ) : (
                        <div>
                            <span className="preferred-location">Preferred Location: {preferredLocation}</span>
                            <button onClick={() => setIsEditing(true)}>Edit</button>
                        </div>
                    )}
                    {userEmail && <span className="email">{userEmail}</span>}
                    <button className="logout-btn" onClick={handleLogout}>Logout</button>
                </div>
                <div className="unit-toggle">
                    <button onClick={toggleUnit}>
                        Switch to {unit === "C" ? "Fahrenheit" : "Celsius"}
                    </button>
                </div>
            </header>

            <div className="content">
            <div className="sidebar ${isSidebarOpen ? 'open' : ''}">
            <div className="text">Menu</div>
            <ul>
                <li>
                    <a href="#" onClick={(e) => { e.preventDefault(); setActiveComponent('ranking'); }}>
                        🏆 Ranking
                    </a>
                </li>
                <li>
                    <a href="#" onClick={(e) => { e.preventDefault(); setActiveComponent('visualization'); }}>
                        📊 Visualization
                    </a>
                </li>
                <li>
                    <a href="#" onClick={(e) => { e.preventDefault(); setActiveComponent('weatherapp'); }}>
                        📍 Monitor Multiple Locations
                    </a>
                </li>
                <li><a href="#" onClick={(e) => { e.preventDefault(); setActiveComponent('trend'); }}>📈 Trend Analysis</a></li>
                <li><a href="#">🚨 Alert Management</a></li>
                <li><a href="#">🔔 Notifications</a></li>
                <li><a href="#">💬 Feedback</a></li>
            </ul>
        </div>

                <div className="main-content">
    {activeComponent === 'ranking' && <Ranking />}
    {activeComponent === 'visualization' && (
        <div>
            <h2>Visualization Component</h2>
            <Home />
            {/* Add any specific content or components for visualization here */}
        </div>
    )}
    {activeComponent === 'weatherapp' && (
        <div>
            <h2>Monitor Multiple Locations</h2>
            <Weatherapp />
        </div>
    )}


    {activeComponent === 'trend' && (
        <div>
            <h2>Trends</h2>
            <WeatherDashboard />
        </div>
    )}
    {activeComponent === 'default' && (
        loading ? (
            <p>Loading data...</p>
        ) : (
            <>
                {aqiData && (
                    <div className="aqi-section">
                        <h2>Air Quality Index (AQI)</h2>
                        <div dangerouslySetInnerHTML={{ __html: aqiData }} />
                    </div>
                )}

                {weatherData.length > 0 && (
                    <div className="weather-section">
                        <h2>Historical Weather Data</h2>
                        {/* Parameter Selection */}
                        <div style={{ marginBottom: "10px" }}>
                            {["temp", "templow", "baro", "wind", "hum"].map((param) => (
                                <label key={param} style={{ marginRight: "10px" }}>
                                    <input
                                        type="checkbox"
                                        checked={selectedParams.includes(param)}
                                        onChange={() => handleCheckboxChange(param)}
                                    />
                                    {param}
                                </label>
                            ))}
                        </div>
                        {/* Dynamic Graph */}
                        <ResponsiveContainer width="100%" height={400}>
                            <LineChart data={weatherData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis
                                    dataKey="date"
                                    tickFormatter={(tick) => new Date(tick).toLocaleDateString()}
                                />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                {selectedParams.map((param, index) => (
                                    <Line
                                        key={param}
                                        type="monotone"
                                        dataKey={param}
                                        stroke={["#ff7300", "#8884d8", "#82ca9d", "#d62728", "#17becf"][index % 5]}
                                        dot={false}
                                    />
                                ))}
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                )}

                {predictionData.length > 0 && (
                    <div className="prediction-section">
                        <h2>Weather Forecast (Next 72 Hours)</h2>
                        <WeatherGraph predictionData={predictionData} />
                    </div>
                )}
                <Ifr url={`/prec?city=${preferredLocation}`} />  {/* Add the Ifr component here */}
            </>
        )
    )}
</div>

            </div>
        </div>
    );
}

export default Home1;