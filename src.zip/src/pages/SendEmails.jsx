import React, { useState } from "react";
import { db } from "./firebase"; // Ensure the path is correct
import { collection, getDocs } from "firebase/firestore";
import emailjs from "emailjs-com";

const SendEmails = () => {
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");

    const sendEmails = async () => {
        setLoading(true);
        setMessage("");

        try {
            // Fetch users from Firestore
            const usersCollection = collection(db, "users");
            const usersSnapshot = await getDocs(usersCollection);
            
            const emails = [];
            usersSnapshot.forEach((doc) => {
                const userData = doc.data();
                if (userData.location) {
                    emails.push({ email: doc.id, location: userData.location });
                }
            });

            if (emails.length === 0) {
                setMessage("No users found with a location.");
                setLoading(false);
                return;
            }

            // Send emails using EmailJS
            for (const user of emails) {
                const templateParams = {
                    to_email: user.email,
                    subject: "Your Location Link",
                    message: `Click the link to view details: https://weather-app-f5ee9.web.app/details?city=${user.location}`
                };

                await emailjs.send(
                    "service_yh5u0nf", 
                    "template_287byjv", 
                    templateParams, 
                    "2LE7a32qHEpFXwNJh"
                );
            }

            setMessage("Emails sent successfully!");
        } catch (error) {
            console.error("Error sending emails:", error);
            setMessage("Failed to send emails.");
        }

        setLoading(false);
    };

    return (
        <div style={{ padding: "20px", textAlign: "center" }}>
            <h2>Send Emails to Users</h2>
            <button onClick={sendEmails} disabled={loading}>
                {loading ? "Sending..." : "Send Emails"}
            </button>
            <p>{message}</p>
        </div>
    );
};

export default SendEmails;
