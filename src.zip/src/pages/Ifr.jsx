import React from 'react';

function Ifr({ url }) {
    return (
        <iframe
            src={url}
            title="Embedded Content"
            width="950"
            height="900"
        />
    );
}

export default Ifr;